package com.online.examination.system.demo.online.examination.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoOnlineExaminationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoOnlineExaminationSystemApplication.class, args);
	}

}
