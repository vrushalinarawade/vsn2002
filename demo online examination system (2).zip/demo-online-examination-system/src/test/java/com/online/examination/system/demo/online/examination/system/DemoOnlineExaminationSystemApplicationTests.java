package com.online.examination.system.demo.online.examination.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoOnlineExaminationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
